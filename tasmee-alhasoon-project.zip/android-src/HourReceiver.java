package com.raneen.hourly;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;
import java.util.Calendar;

public class HourReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        Scheduler.schedule(ctx);
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (Scheduler.getHours(ctx).charAt(h) == '1') {
            ContextCompat.startForegroundService(ctx, new Intent(ctx, PlayService.class));
        }
    }
}
