package com.raneen.hourly;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.Calendar;

public class Scheduler {
    static final String EMPTY = "000000000000000000000000";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("raneen", Context.MODE_PRIVATE);
    }

    static void saveHours(Context c, String s) {
        prefs(c).edit().putString("hours", s).apply();
    }

    static String getHours(Context c) {
        String s = prefs(c).getString("hours", EMPTY);
        return (s != null && s.length() == 24) ? s : EMPTY;
    }

    static void schedule(Context c) {
        String s = getHours(c);
        long nowMs = System.currentTimeMillis();
        long best = -1;
        for (int d = 0; d <= 1; d++) {
            for (int h = 0; h < 24; h++) {
                if (s.charAt(h) != '1') continue;
                Calendar t = Calendar.getInstance();
                t.set(Calendar.HOUR_OF_DAY, h);
                t.set(Calendar.MINUTE, 0);
                t.set(Calendar.SECOND, 0);
                t.set(Calendar.MILLISECOND, 0);
                t.add(Calendar.DAY_OF_YEAR, d);
                long ms = t.getTimeInMillis();
                if (ms > nowMs + 1000 && (best < 0 || ms < best)) best = ms;
            }
        }
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, new Intent(c, HourReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        if (best < 0) return;
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi);
        }
    }
}
