package com.raneen.hourly;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.util.Base64;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;

@CapacitorPlugin(name = "Hourly")
public class HourlyPlugin extends Plugin {

    @PluginMethod
    public void setSchedule(PluginCall call) {
        try {
            JSArray arr = call.getArray("hours");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 24; i++) sb.append(arr.getBoolean(i) ? '1' : '0');
            Scheduler.saveHours(getContext(), sb.toString());
            Scheduler.schedule(getContext());
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void saveSound(PluginCall call) {
        try {
            byte[] bytes = Base64.decode(call.getString("data"), Base64.DEFAULT);
            File f = new File(getContext().getFilesDir(), "sound.bin");
            try (FileOutputStream o = new FileOutputStream(f)) {
                o.write(bytes);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void playNow(PluginCall call) {
        Context c = getContext();
        ContextCompat.startForegroundService(c, new Intent(c, PlayService.class));
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Context c = getContext();
        c.stopService(new Intent(c, PlayService.class));
        call.resolve();
    }

    @PluginMethod
    public void batterySettings(PluginCall call) {
        Context c = getContext();
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + c.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            try {
                Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            } catch (Exception ignored) {
            }
        }
        call.resolve();
    }
}
