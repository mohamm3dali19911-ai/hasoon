import os, shutil

root = 'android/app/src/main'
pkg = f'{root}/java/com/raneen/hourly'
os.makedirs(pkg, exist_ok=True)
for f in os.listdir('android-src'):
    shutil.copy(f'android-src/{f}', pkg)

m = f'{root}/AndroidManifest.xml'
s = open(m, encoding='utf8').read()
perms = '''<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    '''
comps = '''<service android:name=".PlayService" android:exported="false" android:foregroundServiceType="mediaPlayback" />
        <receiver android:name=".HourReceiver" android:exported="false" />
        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
            </intent-filter>
        </receiver>
    '''
s = s.replace('<application', perms + '<application', 1)
s = s.replace('</application>', comps + '</application>', 1)
open(m, 'w', encoding='utf8').write(s)

shutil.copytree('android-res', f'{root}/res', dirs_exist_ok=True)
shutil.rmtree(f'{root}/res/mipmap-anydpi-v26', ignore_errors=True)
print('patched')
